This is a dictionary database having terms and definitions
related to computer science.

Project is written in Python 2.7.
The gui is written in Tkinter.
Database - SQLite3.
Data id scraped using Beautiful Soup from Labautopedia.

Tested on Ubuntu 15.10 and works perfectly.

Issues, modifications, addition of terms and definitions
are welcome.

Looking forward for pull requests!!!
